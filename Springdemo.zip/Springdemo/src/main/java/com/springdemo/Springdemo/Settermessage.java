package com.springdemo.Springdemo;

public class Settermessage {

}
