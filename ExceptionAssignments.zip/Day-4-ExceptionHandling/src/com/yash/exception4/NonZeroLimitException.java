package com.yash.exception4;

public class NonZeroLimitException extends RuntimeException {
	NonZeroLimitException(String msg)
	{
		super(msg);
	}
	
}
