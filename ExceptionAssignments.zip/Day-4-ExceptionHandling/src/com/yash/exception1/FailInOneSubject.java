package com.yash.exception1;

public class FailInOneSubject extends Exception {
	public FailInOneSubject(String msg)
	{
		super(msg);
	}

}
