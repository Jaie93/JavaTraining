package com.yash.exception1;

public class ResultException extends RuntimeException {
	public ResultException(String msg) {
		super(msg);
	}

}
