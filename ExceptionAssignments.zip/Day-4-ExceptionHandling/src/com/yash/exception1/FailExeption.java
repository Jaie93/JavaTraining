package com.yash.exception1;

public class FailExeption extends Exception {
	public FailExeption(String msg) {
		super(msg);

	}

}
