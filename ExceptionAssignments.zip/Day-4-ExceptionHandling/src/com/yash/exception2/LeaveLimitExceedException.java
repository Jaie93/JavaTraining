package com.yash.exception2;

public class LeaveLimitExceedException extends Exception {
	public LeaveLimitExceedException(String s) {
		super(s);
	}

}
