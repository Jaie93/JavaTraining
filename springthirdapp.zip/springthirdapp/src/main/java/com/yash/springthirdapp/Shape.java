package com.yash.springthirdapp;

public abstract class Shape {

	public abstract void draw();
}
